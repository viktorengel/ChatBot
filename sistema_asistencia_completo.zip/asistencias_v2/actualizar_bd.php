<?php
require_once 'config.php';
$conn = conectar();

$sentencias = [
    "CREATE TABLE IF NOT EXISTS config_institucion (
        clave VARCHAR(100) PRIMARY KEY,
        valor TEXT
    )",
    "CREATE TABLE IF NOT EXISTS config_jornadas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(50) NOT NULL UNIQUE,
        activa TINYINT(1) DEFAULT 1,
        orden INT DEFAULT 0
    )",
    "CREATE TABLE IF NOT EXISTS config_niveles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        codigo VARCHAR(20) NOT NULL,
        jornada_id INT NOT NULL,
        activo TINYINT(1) DEFAULT 1,
        orden INT DEFAULT 0,
        FOREIGN KEY (jornada_id) REFERENCES config_jornadas(id)
    )",
    "CREATE TABLE IF NOT EXISTS config_paralelos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nivel_id INT NOT NULL,
        letra VARCHAR(5) NOT NULL,
        UNIQUE KEY unico (nivel_id, letra),
        FOREIGN KEY (nivel_id) REFERENCES config_niveles(id)
    )",
    "CREATE TABLE IF NOT EXISTS config_figuras (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL UNIQUE
    )",
    "CREATE TABLE IF NOT EXISTS cursos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        nivel VARCHAR(50),
        jornada VARCHAR(20) DEFAULT 'Matutina',
        activo TINYINT(1) DEFAULT 1
    )",
    "CREATE TABLE IF NOT EXISTS representantes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        telefono VARCHAR(20) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS estudiantes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        curso_id INT NULL,
        curso VARCHAR(50) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (curso_id) REFERENCES cursos(id)
    )",
    "CREATE TABLE IF NOT EXISTS estudiante_representante (
        id INT AUTO_INCREMENT PRIMARY KEY,
        estudiante_id INT NOT NULL,
        representante_id INT NOT NULL,
        es_principal TINYINT(1) DEFAULT 1,
        UNIQUE KEY unico (estudiante_id, representante_id),
        FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id),
        FOREIGN KEY (representante_id) REFERENCES representantes(id)
    )",
    "CREATE TABLE IF NOT EXISTS docentes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        rol ENUM('admin','docente') DEFAULT 'docente',
        activo TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS docente_cursos (
        docente_id INT NOT NULL,
        curso_id INT NOT NULL,
        PRIMARY KEY (docente_id, curso_id),
        FOREIGN KEY (docente_id) REFERENCES docentes(id),
        FOREIGN KEY (curso_id) REFERENCES cursos(id)
    )",
    "CREATE TABLE IF NOT EXISTS faltas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        estudiante_id INT NOT NULL,
        fecha DATE NOT NULL,
        motivo VARCHAR(200) DEFAULT 'Inasistencia registrada por el docente',
        mensaje_enviado TINYINT(1) DEFAULT 0,
        docente_id INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
    )",
    "ALTER TABLE cursos ADD COLUMN IF NOT EXISTS jornada VARCHAR(20) DEFAULT 'Matutina'",
    "ALTER TABLE faltas ADD COLUMN IF NOT EXISTS docente_id INT NULL",
    "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS curso_id INT NULL",
    "ALTER TABLE estudiantes MODIFY COLUMN curso VARCHAR(50) NULL DEFAULT NULL",
    "ALTER TABLE estudiantes MODIFY COLUMN representante_id INT NULL DEFAULT NULL",
    "ALTER TABLE estudiantes MODIFY COLUMN representante2_id INT NULL DEFAULT NULL",
];

$errores = [];
foreach ($sentencias as $sql) {
    if (!$conn->query($sql)) {
        if (!in_array($conn->errno, [1060, 1061, 1050, 1091])) {
            $errores[] = $conn->error;
        }
    }
}

// Crear usuario administrador por defecto
$pass = password_hash('admin123', PASSWORD_DEFAULT);
$conn->query("INSERT IGNORE INTO docentes (nombre, email, password, rol) VALUES ('Administrador', 'admin@colegio.com', '$pass', 'admin')");

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Instalacion</title>";
echo "<style>body{font-family:Arial;max-width:600px;margin:50px auto;padding:20px}";
echo ".ok{background:#e6f4ea;color:#137333;padding:15px;border-radius:8px;margin-bottom:15px}";
echo ".err{background:#fce8e6;color:#c5221f;padding:10px;border-radius:6px;margin:5px 0;font-size:13px}";
echo ".info{background:#e8f0fe;color:#1a73e8;padding:15px;border-radius:8px;margin-top:15px}";
echo "a{background:#1a73e8;color:white;padding:12px 25px;border-radius:6px;text-decoration:none;display:inline-block;margin-top:15px}";
echo "</style></head><body>";

echo "<h2>Instalacion del Sistema</h2>";

if (empty($errores)) {
    echo "<div class='ok'><strong>Base de datos instalada correctamente.</strong></div>";
} else {
    echo "<div class='ok'><strong>Instalacion completada con advertencias menores.</strong></div>";
    foreach ($errores as $e) echo "<div class='err'>$e</div>";
}

echo "<div class='info'>";
echo "<strong>Credenciales del administrador:</strong><br><br>";
echo "Email: <strong>admin@colegio.com</strong><br>";
echo "Contrasena: <strong>admin123</strong><br><br>";
echo "<em>Cambia estas credenciales despues de iniciar sesion por primera vez.</em>";
echo "</div>";

echo "<a href='login.php'>Ir al sistema</a>";
echo "</body></html>";

$conn->close();
?>
