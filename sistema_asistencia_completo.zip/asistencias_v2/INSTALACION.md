# Sistema de Control de Asistencia — U.E. Pomasqui
## Guía de Instalación Completa

---

## PARTE 1: SERVIDOR LOCAL (WhatsApp)

### Requisitos
- Servidor con Ubuntu Server 24.04 LTS
- Conexión a internet por cable
- Dominio propio con Cloudflare

### 1.1 Instalar Docker
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install docker.io docker-compose -y
sudo systemctl enable docker
sudo systemctl start docker
```

### 1.2 Configurar Evolution API
```bash
mkdir ~/evolution-api && cd ~/evolution-api
nano docker-compose.yml
```

Contenido del docker-compose.yml:
```yaml
version: '3.8'
services:
  evolution-api:
    image: atendai/evolution-api:v1.8.2
    ports:
      - "8080:8080"
    environment:
      - SERVER_URL=https://whatsapp.TUDOMINIO.com
      - AUTHENTICATION_TYPE=apikey
      - AUTHENTICATION_API_KEY=TU_API_KEY_AQUI
      - AUTHENTICATION_EXPOSE_IN_FETCH_INSTANCES=true
    volumes:
      - evolution_data:/evolution/instances
    restart: always
volumes:
  evolution_data:
```

```bash
sudo docker-compose up -d
```

### 1.3 Instalar Cloudflare Tunnel
```bash
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
sudo dpkg -i cloudflared.deb
cloudflared tunnel login
cloudflared tunnel create nombre-tunel
```

Crear /etc/cloudflared/config.yml:
```yaml
tunnel: TU_TUNNEL_ID
credentials-file: /etc/cloudflared/TU_TUNNEL_ID.json

ingress:
  - hostname: whatsapp.TUDOMINIO.com
    service: http://localhost:8080
  - service: http_status:404
```

```bash
sudo cp ~/.cloudflared/TU_TUNNEL_ID.json /etc/cloudflared/
cloudflared tunnel route dns nombre-tunel whatsapp.TUDOMINIO.com
sudo cloudflared service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
```

### 1.4 Conectar WhatsApp
1. Abre https://whatsapp.TUDOMINIO.com/manager
2. Crea una instancia con el nombre configurado
3. Escanea el código QR con WhatsApp del número institucional

---

## PARTE 2: APLICACIÓN WEB (Hosting)

### Requisitos
- Hosting con PHP 8+ y MySQL 8
- Subdominio creado (ej: as.TUDOMINIO.com)
- Acceso a cPanel

### 2.1 Base de Datos
1. En cPanel → Bases de datos MySQL → Crear base de datos
2. Crear usuario y asignar todos los privilegios
3. Anotar: nombre_bd, usuario, contraseña

### 2.2 Configurar el sistema
Edita el archivo `config.php` con tus datos:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'tu_base_de_datos');
define('DB_USER', 'tu_usuario');
define('DB_PASS', 'tu_contrasena');
define('EVOLUTION_URL', 'https://whatsapp.TUDOMINIO.com');
define('EVOLUTION_KEY', 'TU_API_KEY_AQUI');
define('EVOLUTION_INSTANCE', 'nombre_instancia');
```

### 2.3 Subir archivos
Sube todos los archivos PHP y la plantilla Excel al directorio raíz del subdominio.
Ejemplo: /home/usuario/as.TUDOMINIO.com/

### 2.4 Instalar la base de datos
Abre en el navegador:
```
https://as.TUDOMINIO.com/actualizar_bd.php
```
Esto crea todas las tablas y el usuario administrador.

### 2.5 Credenciales iniciales
- Email: admin@colegio.com
- Contraseña: admin123
⚠ Cambia estas credenciales inmediatamente desde Gestión → Docentes.

---

## PARTE 3: CONFIGURAR EL CRON JOB

En cPanel → Trabajos Cron, agrega:
```
* * * * * /usr/local/bin/php /home/USUARIO/as.TUDOMINIO.com/procesar_cola.php && sleep 20 && /usr/local/bin/php /home/USUARIO/as.TUDOMINIO.com/procesar_cola.php && sleep 20 && /usr/local/bin/php /home/USUARIO/as.TUDOMINIO.com/procesar_cola.php
```

---

## PARTE 4: PRIMEROS PASOS EN EL SISTEMA

### Orden recomendado de configuración:
1. Iniciar sesión en https://as.TUDOMINIO.com/login.php
2. Ir a ⚙️ Configuración → Institución y Cursos
3. Llenar datos de la institución
4. Activar las jornadas del colegio
5. Seleccionar niveles por jornada y asignar paralelos
6. Si hay Bachillerato Técnico, agregar las figuras profesionales
7. Generar todos los cursos automáticamente
8. Ir a Gestión → Docentes y registrar los docentes
9. Asignar cursos a cada docente
10. Importar estudiantes con la plantilla Excel o registrar manualmente
11. Vincular representantes a cada estudiante

---

## ESTRUCTURA DE ARCHIVOS

```
actualizar_bd.php    — Instalador de la base de datos
auth.php             — Control de sesiones y roles
cascada_ajax.php     — API para filtros jornada/nivel/curso
config.php           — Configuración de BD y Evolution API
configuracion.php    — Módulo de configuración institucional
contacto.php         — Página para que representantes guarden el contacto
cursos.php           — Gestión de cursos (legacy)
docentes.php         — Gestión de docentes y asignación de cursos
eliminar_falta.php   — Eliminar falta registrada
enviar.php           — Procesar falta individual
enviar_multiple.php  — Procesar faltas de múltiples estudiantes
estudiantes.php      — Gestión de estudiantes
estudiantes_ajax.php — API para buscador de estudiantes
faltas_ajax.php      — API para actualización automática de tabla
header.php           — Menú y estilos globales
importar.php         — Importación masiva desde Excel
index.php            — Registro de faltas (pantalla principal)
login.php            — Inicio de sesión
logout.php           — Cerrar sesión
plantilla_estudiantes.xlsx — Plantilla para importar estudiantes
procesar_cola.php    — Script del cron para enviar WhatsApp
reportes.php         — Módulo de reportes con filtros
reportes_ajax.php    — API para actualización de reportes
representantes.php   — Gestión de representantes
```

---

## NOTAS IMPORTANTES

- El archivo `procesar_cola.php` NO debe ser accesible públicamente en producción
- Cambia el API key de Evolution API por uno seguro
- La sesión de WhatsApp persiste aunque el servidor se reinicie (gracias al volumen Docker)
- Para reconectar WhatsApp: https://whatsapp.TUDOMINIO.com/manager
- Los logs de envío se guardan en `cron_log.txt`

