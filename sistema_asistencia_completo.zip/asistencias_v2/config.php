<?php
// ============================================
// CONFIGURACION BASE DE DATOS
// Edita estos valores con los datos de tu hosting
// ============================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'nombre_base_de_datos');
define('DB_USER', 'usuario_base_de_datos');
define('DB_PASS', 'contrasena_base_de_datos');

// ============================================
// CONFIGURACION EVOLUTION API (WhatsApp)
// ============================================
define('EVOLUTION_URL', 'https://whatsapp.tudominio.com');
define('EVOLUTION_KEY', 'tu_api_key_aqui');
define('EVOLUTION_INSTANCE', 'nombre_instancia');

// ============================================
// CONEXION A BASE DE DATOS
// ============================================
function conectar() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Error de conexion: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}

// ============================================
// NORMALIZAR TELEFONO ECUATORIANO
// ============================================
function normalizar_telefono($telefono) {
    $tel = preg_replace('/\D/', '', $telefono);
    if (empty($tel)) return '';
    if (substr($tel, 0, 3) === '593') return $tel;
    if (substr($tel, 0, 1) === '0') return '593' . substr($tel, 1);
    if (strlen($tel) === 9) return '593' . $tel;
    return $tel;
}
?>
